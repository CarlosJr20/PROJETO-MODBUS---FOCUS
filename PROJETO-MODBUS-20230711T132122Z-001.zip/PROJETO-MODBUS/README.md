<h1 align="center"> API MODBUS FOCUS AUTOMAÇÃO E SISTEMAS </h1>

## Instalação
```
npm init
npm install express
npm install jsmodbus 
```
## Executar 
```
node api.js
```
<a href="https://focusautomacao.com.br" target="_blank"> <img width="250" src="https://focusautomacao.com.br/wp-content/uploads/2022/02/Ativo-1.png"> </a>
